/**2018-06-29
 * 1.0.1
 */

window.onload=function (){uigrow_sortTable_main();}

function uigrow_sortTable_main(){
	var all_tables=document.getElementsByTagName("table");
	for(var i=0;i<all_tables.length;i++)
	{
		var table_obj=all_tables[i];
		var class_name=table_obj.className;
		if(class_name.indexOf("uigrow_sort_table")!=-1)
		{
			var all_tr=table_obj.getElementsByTagName("tr");
			var first_tr=all_tr[0];
			first_tr.style.cursor="pointer";
			var all_childs=uigrow_sortTable_getTrChilds(first_tr);
			for(var j=0;j<all_childs.length;j++)
			{
				all_childs[j].onclick=function(){uigrow_sortTable(this);};
			}
		}
	}
}

function uigrow_sortTable(this_obj){
	var obj_index=this_obj.cellIndex;
	var this_class_name=this_obj.className;
	var compel_type="";
	if(this_class_name.indexOf("uigrow_order_by_number")!=-1){
		compel_type="number";
	}else if(this_class_name.indexOf("uigrow_order_by_string")!=-1){
		compel_type="string";
	}
	
	var is_positive_sequence;
	if(this_obj.innerHTML.indexOf("<span style=\"margin-left:2px;line-height:100%;\">▴</span>")!=-1){
		is_positive_sequence=false;
		this_obj.innerHTML=this_obj.innerHTML.replace("<span style=\"margin-left:2px;line-height:100%;\">▴</span>","");
		this_obj.innerHTML+="<span style=\"margin-left:2px;line-height:100%;\">▾</span>";
	}else{
		is_positive_sequence=true;
		this_obj.innerHTML=this_obj.innerHTML.replace("<span style=\"margin-left:2px;line-height:100%;\">▾</span>","");
		this_obj.innerHTML+="<span style=\"margin-left:2px;line-height:100%;\">▴</span>";
	}
	
	var table_obj=this_obj.parentNode.parentNode.parentNode;
	var all_tbodys=table_obj.getElementsByTagName("tbody");
	var first_tbody=all_tbodys[0];
	var tr_array=new Array();
	var all_tr=first_tbody.getElementsByTagName("tr");
	var all_is_num=true;
	for(var i=0;i<all_tr.length;i++){
		var all_td=all_tr[i].getElementsByTagName("td");
		var td_obj=all_td[obj_index];
		if(!uigrow_checkNumber(td_obj.innerHTML)){
			all_is_num=false;
		}
	}
	if(compel_type=="number"){
		for(var i=0;i<all_tr.length;i++)
		{
			var all_td=all_tr[i].getElementsByTagName("td");
			var td_obj=all_td[obj_index];
			var tr_obj=new Object();
			tr_obj.value=parseFloat(td_obj.innerHTML.replace(/[^0-9]/ig,""));
			tr_obj.tr=all_tr[i];
			tr_array[i]=tr_obj;
		}
	}else if(compel_type=="string"){
		for(var i=0;i<all_tr.length;i++)
		{
			var all_td=all_tr[i].getElementsByTagName("td");
			var td_obj=all_td[obj_index];
			var tr_obj=new Object();
			tr_obj.value=td_obj.innerHTML;
			tr_obj.tr=all_tr[i];
			tr_array[i]=tr_obj;
		}
	}else{
		if(all_is_num){
			for(var i=0;i<all_tr.length;i++)
			{
				var all_td=all_tr[i].getElementsByTagName("td");
				var td_obj=all_td[obj_index];
				var tr_obj=new Object();
				tr_obj.value=parseFloat(td_obj.innerHTML);
				tr_obj.tr=all_tr[i];
				tr_array[i]=tr_obj;
			}
		}else{
			for(var i=0;i<all_tr.length;i++)
			{
				var all_td=all_tr[i].getElementsByTagName("td");
				var td_obj=all_td[obj_index];
				var tr_obj=new Object();
				tr_obj.value=td_obj.innerHTML;
				tr_obj.tr=all_tr[i];
				tr_array[i]=tr_obj;
			}
		}
	}
	
	if(is_positive_sequence){
		for(var i=0;i<tr_array.length-1;i++)
		{
			for(var j=0;j<tr_array.length-1-i;j++){
	            if(tr_array[j].value>tr_array[j+1].value){
	                var temp = tr_array[j];
	                tr_array[j] = tr_array[j+1];
	                tr_array[j+1] = temp;
	            }
	        } 
		}
	}else{
		for(var i=0;i<tr_array.length-1;i++)
		{
			for(var j=0;j<tr_array.length-1-i;j++){
	            if(tr_array[j].value<tr_array[j+1].value){
	                var temp = tr_array[j];
	                tr_array[j] = tr_array[j+1];
	                tr_array[j+1] = temp;
	            }
	        } 
		}
	}
	
	var all_theads=table_obj.getElementsByTagName("thead");
	var first_tr=all_theads[0].getElementsByTagName("tr")[0];
	var all_childs=uigrow_sortTable_getTrChilds(first_tr);
	for(var i=0;i<all_childs.length;i++){
		if(obj_index!=i){
			all_childs[i].innerHTML=all_childs[i].innerHTML.replace("<span style=\"margin-left:2px;line-height:100%;\">▾</span>","");
			all_childs[i].innerHTML=all_childs[i].innerHTML.replace("<span style=\"margin-left:2px;line-height:100%;\">▴</span>","");
		}
	}
	first_tbody.innerHTML="";
	for(var i=0;i<tr_array.length;i++)
	{
		first_tbody.appendChild(tr_array[i].tr);
	}
}

function uigrow_sortTable_getTrChilds(tr_obj){
	var all_td=tr_obj.getElementsByTagName("td");
	var all_th=tr_obj.getElementsByTagName("th");
	if(all_td.length>0)
	{
		return all_td;
	}else if(all_th.length>0){
		return all_th;
	}else{
		return null;
	}
}

function uigrow_checkNumber(theObj) {
	var reg1 = /^[0-9]+$/;
	var reg2=/^[-]?[0-9]+$/;
	var reg3 = /^[0-9]+.?[0-9]*$/;
	var reg4 = /^[-]?[0-9]+\.?[0-9]+?$/ ;
	
	if(reg1.test(theObj)){
		return true;
	}else{
		if(reg2.test(theObj)){
			return true;
		}else{
			if (reg3.test(theObj)){
				return true;
			}else{
				if(reg4.test(theObj)){
					return true;
				}else{
					return false;
				}
			}
		}
	}
}



